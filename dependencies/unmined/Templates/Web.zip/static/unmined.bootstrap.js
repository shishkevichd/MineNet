function Bootstrap() {
  this.set = function (options) {
    $("#meta_serverName").text(options.meta.ServerName);
  };
}
